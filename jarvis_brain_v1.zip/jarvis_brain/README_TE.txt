JARVIS BRAIN V1 — తెలుగు సెటప్

1. ఈ folder‌ను computer‌లో ఉంచండి.
2. Node.js LTS install చేసి ఉండాలి.
3. Terminal/Command Prompt‌లో ఈ folder‌కు వెళ్లి: npm install
4. .env.example copy చేసి .env అని పేరు పెట్టండి.
5. .envలో OPENAI_API_KEY=... దగ్గర మీ API key పెట్టండి.
6. npm start run చేయండి.
7. Browserలో http://127.0.0.1:3000 తెరవండి.
8. Mic permission Allow చేయండి.

ముఖ్యమైనది: API key‌ను jarvis.htmlలో ఎప్పుడూ పెట్టకండి. అది backend .envలోనే ఉండాలి.
API usage వల్ల account pricing ప్రకారం charges రావచ్చు.
