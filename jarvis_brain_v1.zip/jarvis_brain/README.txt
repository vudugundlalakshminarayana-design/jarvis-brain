JARVIS BRAIN V1

1) Install Node.js (LTS) on your computer.
2) Open a terminal in this folder.
3) Run: npm install
4) Copy .env.example to .env
5) Put your OpenAI API key in .env. Keep it private; never put it inside jarvis.html.
6) Run: npm start
7) Open: http://127.0.0.1:3000

The browser sends your message only to this local backend. The backend sends it to the OpenAI Responses API.
API usage can incur charges according to the account's current pricing.
