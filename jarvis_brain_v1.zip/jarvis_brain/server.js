import express from 'express';
import OpenAI from 'openai';
import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 3000);
const model = process.env.OPENAI_MODEL || 'gpt-6-luna';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (!process.env.OPENAI_API_KEY) {
  console.warn('OPENAI_API_KEY is not set. Add it to .env before starting JARVIS.');
}

const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.use(express.json({ limit: '32kb' }));
app.use(express.static(__dirname));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, brain: Boolean(client), model });
});

app.post('/api/chat', async (req, res) => {
  try {
    if (!client) {
      return res.status(503).json({ error: 'JARVIS brain is not configured. Add OPENAI_API_KEY to .env.' });
    }

    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    if (!message) {
      return res.status(400).json({ error: 'Message is required.' });
    }
    if (message.length > 4000) {
      return res.status(400).json({ error: 'Message is too long.' });
    }

    const response = await client.responses.create({
      model,
      instructions: `You are JARVIS, a helpful personal AI assistant.\n\nStyle:\n- Be concise, clear, and friendly.\n- Reply in the same language as the user; Telugu is the default for this project.\n- Address the user as Sir when natural, but do not overuse it.\n- Never claim to have performed an action unless the app actually performed it.\n- For unsupported device actions, explain what is needed instead.\n- Do not invent facts.`,
      input: [{ role: 'user', content: message }]
    });

    res.json({ text: response.output_text || 'I did not receive a text response.' });
  } catch (error) {
    console.error(error);
    const status = error?.status >= 400 && error.status < 600 ? error.status : 500;
    res.status(status).json({ error: error?.message || 'JARVIS brain request failed.' });
  }
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'jarvis.html'));
});

app.listen(port, '127.0.0.1', () => {
  console.log(`JARVIS running at http://127.0.0.1:${port}`);
});
