@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Installing JARVIS dependencies...
  npm install
)
if not exist .env (
  copy .env.example .env >nul
  echo.
  echo Created .env. Put your OpenAI API key in .env, then run this file again.
  pause
  exit /b
)
npm start
